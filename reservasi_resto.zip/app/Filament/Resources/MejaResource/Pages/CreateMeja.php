<?php

namespace App\Filament\Resources\MejaResource\Pages;

use App\Filament\Resources\MejaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMeja extends CreateRecord
{
    protected static string $resource = MejaResource::class;
}
