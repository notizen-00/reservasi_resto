

<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <h2>Riwayat Transaksi</h2>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Nomor Transaksi</th>
                <th>Nomor Meja</th>
                <th>Total Transaksi</th>
                <th>Tanggal & Jam Pemesanan</th>
                <th>Status Transaksi</th>
                <th>Status Pembayaran</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if($transaksi->count() != 0): ?>
            <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($item->nomor_transaksi); ?></td>
                <td><?php echo e($item->meja->nomor_meja); ?></td>
                <td>Rp. <?php echo e(number_format($item->total, 2)); ?></td>
                <td><?php echo e($item->tanggal_reservasi); ?> -- <?php echo e($item->jam_reservasi); ?></td>
                <td>
                    <?php if($item->status_transaksi->name == 'Pending'): ?>
                    <span class="badge bg-dark">Pending</span>
                    <?php elseif($item->status_transaksi->name == 'Verified'): ?>
                    <span class="badge bg-info">Verified</span>
                    <?php elseif($item->status_transaksi->name == 'Proses'): ?>
                    <span class="badge bg-warning">Proses</span>
                    <?php elseif($item->status_transaksi->name == 'Selesai'): ?>
                    <span class="badge bg-success">Selesai</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($item->pembayaran->status_pembayaran == 0): ?>
                    <span class="badge bg-danger">Belum Lunas</span>
                    <?php else: ?>
                    <span class="badge bg-success">Lunas</span>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="d-flex justify-content-around">

                        <button class="btn btn-sm btn-outline-info transaksi-view" data-id="<?php echo e($item->id); ?>"><i
                                class="fa-duotone fa-eye"></i> Lihat </button>
                        <button class="btn btn-sm btn-outline-warning transaksi-payment"
                            data-id="<?php echo e($item->pembayaran->id); ?>"><i class="fa-duotone fa-credit-card"></i> Bayar
                        </button>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr class="text-center">
                <td colspan="6">Data Transaksi Kosong Silahkan Lakukan Transaksi <br> <a href="<?php echo e(url('/')); ?>"
                        class="btn btn-outline-primary ">Buat Transaksi</a></td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout_transaksi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon8\www\reservasi_resto\resources\views/transaksi/v_index.blade.php ENDPATH**/ ?>