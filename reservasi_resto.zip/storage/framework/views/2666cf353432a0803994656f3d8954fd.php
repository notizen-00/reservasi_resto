 <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4 px-lg-5 py-3 py-lg-0">
     <a href="" class="navbar-brand p-0">
         <h1 class="text-primary m-0"><i class="fa fa-utensils me-3"></i>E-Resto</h1>
         <!-- <img src="img/logo.png" alt="Logo"> -->
     </a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
         <span class="fa fa-bars"></span>
     </button>
     <div class="collapse navbar-collapse" id="navbarCollapse">
         <div class="navbar-nav ms-auto py-0 pe-4">

             <a href="<?php echo e(url('/')); ?>" class="nav-item nav-link <?php echo e(Request::is('/') ? 'active' : ''); ?>">Home</a>
             <a href="about.html" class="nav-item nav-link">About</a>
             <a href="service.html" class="nav-item nav-link">Service</a>
             <a href="<?php echo e(url('/transaksi')); ?>"
                 class="nav-item nav-link <?php echo e(Request::is('transaksi') ? 'active' : ''); ?>">Transaksi</a>
         </div>

         <?php if(auth()->guard()->check()): ?>

         <a href="<?php echo e(route('cart.index')); ?>" class="btn btn-secondary py-2 px-4 me-2 position-relative">
             <i class="fa fa-shopping-cart me-2"></i>
             <span class="badge bg-danger position-absolute top-0 start-100 translate-middle" id="cart-count">
                 <?php echo e(Cart::content()->count()); ?>

             </span>
         </a>
         <div class="nav-item dropdown">
             <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                 <i class="fa fa-user me-2"></i><?php echo e(Auth::user()->name); ?>

             </a>
             <div class="dropdown-menu m-0">
                 <a href="#" class="dropdown-item">Profile</a>
                 <a href="<?php echo e(route('pelanggan.logout')); ?>" class="dropdown-item"
                     onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                     Logout
                 </a>
                 <form id="logout-form" action="<?php echo e(route('pelanggan.logout')); ?>" method="POST" class="d-none">
                     <?php echo csrf_field(); ?>
                 </form>
             </div>
         </div>

         <?php else: ?>
         <a href="<?php echo e(route('pelanggan.login.form')); ?>" class="btn btn-primary py-2 px-4">Member</a>
         <?php endif; ?>
     </div>
 </nav>
<?php /**PATH C:\laragon8\www\reservasi_resto\resources\views/layout/navbar.blade.php ENDPATH**/ ?>